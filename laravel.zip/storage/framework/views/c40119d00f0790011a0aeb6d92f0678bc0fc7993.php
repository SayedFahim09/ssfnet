
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <ol>
          <li>Category ID:   <?php echo e($category->id); ?></li>
          <li>Category Name: <?php echo e($category->name); ?></li>
          <li>Category Slug: <?php echo e($category->slug); ?></li>
        </ol>
      
  </div>
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/posts/categorie/viewCategorie.blade.php ENDPATH**/ ?>