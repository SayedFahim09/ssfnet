
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-lg-12 mx-auto">
        <a href="<?php echo e(url('/resource/create')); ?>" class="btn btn-success">Add Student</a>
        <hr>
        <table class="table table-striped table-bordered table-striped">
          <thead>
            <tr class="bg-info">
          
              <th scope="col">No.</th>
              <th scope="col">Student Name</th>
              <th scope="col">Student Email</th>
              <th scope="col">Student Phone</th>
              
              <th scope="col">EDIT</th>
              <th scope="col">DELETE</th>
              <th scope="col">View</th>
            </tr>
          </thead>

          <tbody>
           <?php
              $i=1;
           ?>
          <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
             <tr class="text-center">
          
              <th scope="row"><?php echo e($i); ?></th>
              <td><?php echo e($row->name); ?></td>
              <td><?php echo e($row->email); ?></td>
              <td><?php echo e($row->phone); ?></td>
                            
          
              <td><a href="<?php echo e(URL::to('resource/'.$row->id.'/edit')); ?>"><button type="button" class="btn btn-info">Edit</button></a></td>

              <td>
                
                  <form action="<?php echo e(URL::to('resource/'.$row->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Delete</button>
                  </form>
                
              </td>

              <td><a href="<?php echo e(URL::to('resource/'.$row->id)); ?>"><button type="button" class="btn btn-warning">View</button></a></td>
             
            </tr>

           <?php
             $i++;
           ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>

        </table>
  
  </div>
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/resource/index.blade.php ENDPATH**/ ?>