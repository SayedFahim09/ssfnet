
<?php $__env->startSection('content'); ?>
<div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <div class="post-preview">
            
             <img src="<?php echo e(URL::to($row->image)); ?>" style="height: 300px;">

            <a href="#">
            <h2 class="post-title">
                <?php echo e($row->title); ?>

            </h2>
            </a>

            <p class="post-meta">Category
              <a href="#"><?php echo e($row->name); ?></a>
              on Slug <?php echo e($row->slug); ?>

            </p>
          </div>
          <hr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Pager -->
        <div class="clearfix">
           <?php echo e($post->links()); ?>

        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/index.blade.php ENDPATH**/ ?>