
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
      	
          <h2>Name:  <?php echo e($student->name); ?> </h2>
          <h2>Email: <?php echo e($student->email); ?> </h2>
          <h2>Phone: <?php echo e($student->phone); ?> </h2>
              
            
  </div>
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/resource/show.blade.php ENDPATH**/ ?>