
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        
        <table class="table table-striped table-bordered table-striped">
          <thead>
            <tr class="bg-info">
          
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Category</th>
              
              <th scope="col">EDIT</th>
              <th scope="col">DELETE</th>
              <th scope="col">View</th>
            </tr>
          </thead>

          <tbody>

          <?php $__currentLoopData = $categorie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
             <tr>
          
              <th scope="row"><?php echo e($row->id); ?></th>
              <td><?php echo e($row->name); ?></td>
              <td><?php echo e($row->slug); ?></td>
              
          
              <td><a href="<?php echo e(URL::to('/posts/categorie/editCategorie/'.$row->id)); ?>"><button type="button" class="btn btn-success">Edit</button></a></td>

              <td><a href="<?php echo e(URL::to('/posts/categorie/deleteCategorie/'.$row->id)); ?>" class="btn btn-sm btn-danger" id="delete">Delete</a></td>


              <td><a href="<?php echo e(URL::to('/posts/categorie/viewCategorie/'.$row->id)); ?>"><button type="button" class="btn btn-warning">View</button></a></td>
             
            </tr>


          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          
          </tbody>

        </table>
  
  </div>
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/posts/categorie/allCategorie.blade.php ENDPATH**/ ?>