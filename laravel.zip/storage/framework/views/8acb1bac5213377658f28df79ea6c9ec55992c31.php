
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
      	
          <h2> <?php echo e($view->title); ?> </h2>
          <img src="<?php echo e(URL::to($view->image)); ?>" height="340px;">
          <p> Category Name: <?php echo e($view->name); ?> </p>
          <p> <?php echo e($view->details); ?> </p>
            
  </div>
 </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/posts/viewPost.blade.php ENDPATH**/ ?>